from kitwebsite import create_app
from flask import session
from flask_session import Session
import os

app = create_app()

app.config['TEMPLATES_AUTO_RELOAD'] = True

app.config['SESSION_PERMANENT'] = True

app.config['SESSION_TYPE'] = 'filesystem'

app.config['SESSION_FILE_THRESHOLD'] = 100  

app.config['SECRET_KEY'] = '45e0dc97a716e16535c79cc2047653bc72fc8e9151889cee29cb67202c41405b4e48163e600de0d971f6b73339f1a8504a47b5905412cf7cf0f57a31829d162f124bcaf35c955752158964cfc2d02488d15b08465017cef7675b2ad077556e4b905b2d9393c155b86dfe54cd3e40cc22313c62c06edb3df94d2cef73e17ae3b354fa9548f75981cd571729ee38a0aabdeeb6b759f2d3308f6c5c3c940b8edbff05e4b6eff6b2c78922f1ba7df6e55f8061f2ff4751f40855dc04a2365fe05fcdfd1aa03f62b383802925f619e66f62e046b796e582ffdcba1d9368be66efd6cb66a16eff3b79c457940dc3d7811de871108d037812d41757f15cf96f923a5743'    


sess = Session()
sess.init_app(app)

port = int(os.environ.get("PORT", 5000))

host = "0.0.0.0"


if __name__ == '__main__':
    app.run(debug=False, host=host, port=port)
