#  _  _____ _____  __        __                               
# | |/ /_ _|_   _| \ \      / / __ __ _ _ __  _ __   ___ _ __ 
# | ' / | |  | |    \ \ /\ / / '__/ _` | '_ \| '_ \ / _ \ '__|
# | . \ | |  | |     \ V  V /| | | (_| | |_) | |_) |  __/ |   
# |_|\_\___| |_|      \_/\_/ |_|  \__,_| .__/| .__/ \___|_|   
#                                      |_|   |_|              
#
'''
KIT Wrapper

Command line tool to enable easier use of WMC Global KIT API

For API key please contact WMC Global :: https://www.wmcglobal.com/contact

Author :: Jake 


Change log:
	- Overhaul of upload system
	- Added debug option
	- Logic changes to submit process

''' 
__version__ = '2.7.13'


# Import Table
from copy import deepcopy
from tqdm import tqdm
from tqdm.utils import CallbackIOWrapper
from typing import Dict, Any, List
import argparse
import errno
import feedparser
import glob
import hashlib
import json
import os
import pandas
import pathlib
import re
import requests
import shutil
import time
import traceback
import uuid
from flask import session


## Global Config options
# Content download location
Default_Download_Location = os.getcwd()

# KIT URL base endpoint
URL_Endpoint = 'https://api.phishfeed.com/KIT/v1'

VAILD_KEYWORDS = {
	"datetime": "datetime",
	"content": "content",
	"file.filename": "file.filename",
	"file.filetype": "file.filetype",
	"file.md5": "file.md5",
	"file.sha256": "file.sha256",
	"file.size": "file.size",
	"file.ssdeep": "file.ssdeep",
	"file.UUID": "file.UUID",
	"filename": "file.filename",
	"filetype": "file.filetype",
	"fullfilename": "fullfilename",
	"file.fullfilename": "fullfilename",
	"kit.filetype": "kit.filetype",
	"kit.kitname": "kit.kitname",
	"kit.md5": "kit.md5",
	"kit.sha256": "kit.sha256",
	"kit.size": "kit.size",
	"kit.ssdeep": "kit.ssdeep",
	"kit.UUID": "kit.UUID",
	"md5": "file.md5",
	"scroll_id": "scroll_id",
	"sha256": "file.sha256",
	"size": "file.size",
	"size_filter": "size_filter",
	"ssdeep": "file.ssdeep",
	"UUID": "UUID",
}

# Function to access content API
def content(uuidInput, downloadInput, debug):
	# KIT API environment variable
	try:
		if os.environ['KITAPI'] is not None:
			Env_KIT_APIKey = os.environ['KITAPI']
		else:
			Env_KIT_APIKey = session['apikey']
	except Exception as e:
		# Error
		print ("ERROR\t- KITAPI key error - Ensure an API key has been added to the environment variables")
		exit()

	try:
		if os.environ['KITINTEL_CERT_VALIDATION'] is not None:
			certs = os.environ['KITINTEL_CERT_VALIDATION']
		else:
			certs = session['KITINTEL_CERT_VALIDATION']
		if certs.lower() == "false":
		    certs = False
	except KeyError:
		certs = True
	except Exception as e:
		print (f"Error: {e}")

	# Allow for multiple UUIDs
	for target_uuid in uuidInput:
		try:
			target_uuid = target_uuid.strip(',')
			headers = {'x-api-key': Env_KIT_APIKey, 'Content-Type': 'application/json'}
			data = {}
			data['UUID'] = target_uuid
			# POST request to the endpoint
			response = requests.post(URL_Endpoint + "/content", headers=headers, data=json.dumps(data), verify=certs)
			if response.status_code == 200:
				result = response.json()
				# extract the content download URL
				target_url = (result['download_url'])
				response = requests.get("{}".format(target_url), verify=certs)
				if response.status_code == 200:
					# If saving to file
					return (response.text)
				else:
					# Error
					return ("ERROR\t- Failed to download content for {}".format(target_uuid))
					if debug:
						traceback.print_exc()
						print (response.text)
			elif response.status_code == 403:
				return  ("ERROR\t- Forbidden")
				if debug:
					traceback.print_exc()
			else:
				# Error
				return ("ERROR\t- Failed to request content for {}".format(target_uuid))
				if debug:
					traceback.print_exc()
					print (response.text)
		except Exception as e:
			# Error
			return ("ERROR\t- Failed to parse {}".format(target_uuid))
			if debug:
				traceback.print_exc()
				print (e)

def cross_join(left, right):
	new_rows = [] if right else left
	for left_row in left:
		for right_row in right:
			temp_row = deepcopy(left_row)
			for key, value in right_row.items():
				temp_row[key] = value
			new_rows.append(deepcopy(temp_row))
	return new_rows


def flatten_list(data):
	for elem in data:
		if isinstance(elem, list):
			yield from flatten_list(elem)
		else:
			yield elem


def json_to_dataframe(data_in):
	def flatten_json(data, prev_heading=''):
		if isinstance(data, dict):
			rows = [{}]
			for key, value in data.items():
				rows = cross_join(rows, flatten_json(value, prev_heading + '.' + key))
		elif isinstance(data, list):
			rows = []
			for i in range(len(data)):
				[rows.append(elem) for elem in flatten_list(flatten_json(data[i], prev_heading))]
		else:
			rows = [{prev_heading[1:]: data}]
		return rows

	return pandas.DataFrame(flatten_json(data_in))


def recursive_get(value: Dict[str, Any], path: List[str], default: Any = None) -> Any:
	current_point = value
	for key in path:
		try:
			current_point = current_point[key]
		except KeyError:
			return default
	return current_point


# Function to search KIT
def search(searchInput, filterInput=None, numberInput=None, dateGTEInput='5y', uniqueInput=None, formatInput=None, downloadInput=None, debug=None, dateLTEInput=None):
	# KIT API environment variable
	try:
		if os.environ['KITAPI'] is not None:
			Env_KIT_APIKey = os.environ['KITAPI']
		else:
			Env_KIT_APIKey = session['apikey']
	except Exception as e:
		# Error
		print ("ERROR\t- KITAPI key error - Ensure an API key has been added to the environment variables")
		exit()

	cert_val = session.get('cert_val')
	certs = os.environ.get('KITINTEL_CERT_VALIDATION') or (cert_val.lower() == 'true') if cert_val else True


	headers = {'x-api-key': Env_KIT_APIKey, 'Content-Type': 'application/json'}
	data = {}
	debug = True
	# Split search parameters
	search_array = searchInput.split(' IN ')
	# print ('search_array#1: {}'.format(search_array))
	# Regex pattern to split keyword and search variable
	# Fine first occournace of : and then capture the rest of the string
	pattern = r"([^:]*)(.*)"

	# Loop through the search input
	for i in range(len(search_array)):
		try:
			# Extract the regex results
			matchObj = re.search(pattern, search_array[i])
			# Check there are hits from the regex
			if matchObj:
				# Strip away a space in the keyword
				keyword = str(matchObj.group(1)).replace(' ', '')
				# Strip char 1 from the value which will always be a ':' due to the regex
				value = str(matchObj.group(2)[1:])
				# Check to ensure the keyword is able to be searched
				if keyword in VAILD_KEYWORDS.keys():
					if keyword == 'scroll_id':
						data[keyword] = int(value)
					else:
						keyword = VAILD_KEYWORDS[keyword]
						data[keyword] = value
				else:
					# Error
					if debug:
						traceback.print_exc()
					return ("ERROR\t- '{}' - Unknown search term. Please try again".format(keyword))
					exit()
			else:
				# Error	
				if debug:
					traceback.print_exc()
				return ("ERROR\t- Invalid key:value pair")
				exit()
		except Exception as e:
			# Error
			print (e)
			if debug:
				traceback.print_exc()
			return ("ERROR\t- Ensure search is valid with keyword:search_term")
	# Parse filter argument
	if filterInput:
		filterItems = []
		for keyword in filterInput.split(','):
			keyword = keyword.strip()
			if keyword in VAILD_KEYWORDS.keys():
				keyword = VAILD_KEYWORDS[keyword]
				filterItems.append(keyword)
			else:
				# Error
				if debug:
					traceback.print_exc()
				return ("ERROR\t- '{}' - Unknown filter term. Please try again".format(keyword))
				exit()

		data["filter"] = filterItems
		# filterData = (filterItems)
		# print (filterItems)

	# Parse number argument
	if numberInput:
		data["page_size"] = int(numberInput)

	# Parse date argument
	if dateLTEInput:
		date = {}
		date["gte"] = str(dateGTEInput)
		date["lte"] = str(dateLTEInput)
		data["datetime_filter"] = date
	elif dateGTEInput:
		date = {}
		date["gte"] = 'now-' + str(dateGTEInput)
		data["datetime_filter"] = date
		
	# Generate the JSON object from the search dictionary
	data = json.dumps(data)
	print ("API Search: {}".format(data))
	try:
		# POST request to the endpoint
		response = requests.post(URL_Endpoint + "/search", data=data, headers=headers, verify=certs)
		# print ('response#2: {}'.format(response.text))
	except Exception as e:
		# Error
		if debug:
			traceback.print_exc()
		return ("ERROR\t- Failed search POST")

	if response.status_code == 200:
		parsed = json.loads(response.text)
		# Parse unique argument
		if uniqueInput:
			keyword = uniqueInput.strip()
			if keyword in VAILD_KEYWORDS.keys():
				keyword = VAILD_KEYWORDS[keyword]
				uniqueItem = VAILD_KEYWORDS[keyword].split('.')
				print (parsed["results"])
				parsed["results"] = list({ recursive_get(each,uniqueItem) : each for each in parsed["results"] }.values())
				parsed["unique_count"] = len(parsed["results"])
			else:
				# Error
				if debug:
					traceback.print_exc()
				return ("ERROR\t- '{}' - Unknown unique term. Please try again".format(keyword))
				exit()

		content = json.dumps(parsed)
		return {'content': content, 'data': data}

	elif response.status_code == 403:
		if debug:
			traceback.print_exc()
		return ("ERROR\t- Forbidden")
	else:
		# Error
		traceback.print_exc()
		print (response.text)
		return ("ERROR\t- Failed search")

# Function to validate zip file before submission
def validateZip(target_zip, zipsha256, debug):
	if target_zip.lower().endswith('.zip'):
		try:
			with open(target_zip, 'rb') as f:
				header_byte = f.read()[0:4].hex().lower()
				# Check header bytes comply with PKZIP archive file
				if header_byte == '504b0304':
					f.close()
					if debug:
						print ("Passed zip validation")
					return True 
				else:
					# Error
					print ("ERROR#1\t- File not a '.zip' file\t\t\t- Filename: {}".format(os.path.basename(target_zip)))
					if debug:
						print ("Failed zip validation")
						traceback.print_exc()
					f.close()
					return False
		except IOError as e:
			# Error
			print ("ERROR\t- Unable to read file\t\t\t- Filename: {}".format(os.path.basename(target_zip)))
			if debug:
				traceback.print_exc()
				print (e)
			return False
	else:
		# Error
		print ("ERROR#2\t- File not a '.zip' file\t\t\t- Filename: {}".format(os.path.basename(target_zip)))
		if debug:
			traceback.print_exc()
		return False

# Function to prevent duplicate kit submission
# Note: There is a duplication checker on the back end, this is to save wasting submission quotas
# It is strongly recommended you keep this check before submitting kits as duplicates will not be processed
def duplicateChecker(target_zip, zipsha256, debug):
	# KIT API environment variable
	try:
		if os.environ['KITAPI'] is not None:
			Env_KIT_APIKey = os.environ['KITAPI']
		else:
			Env_KIT_APIKey = session['apikey']
	except Exception as e:
		# Error
		print ("ERROR\t- KITAPI key error - Ensure an API key has been added to the environment variables")
		exit()

	cert_val = session.get('cert_val')
	certs = os.environ.get('KITINTEL_CERT_VALIDATION') or (cert_val.lower() == 'true') if cert_val else True

	headers = {'x-api-key': Env_KIT_APIKey, 'Content-Type': 'application/json'}
	data = {
		"filter": ["kit.UUID"],
		"page_size": 1
	}
	data['kit.sha256'] = zipsha256
	try:
		# Slow down multi-kit ingest to avoid duplicate kit overlaps
		time.sleep(1)
		# POST request to the endpoint
		if debug:
			print ("Making search POST - " + str(time.time()))
			print (data)
		response = requests.post(URL_Endpoint + "/search", data=json.dumps(data), headers=headers, verify=certs)
		if debug:
			print ("Finished  search POST - " + str(time.time()))
		if response.status_code == 403:
			print ("Uploader only restrictions apply - ", end='')
			return True
		if response.status_code == 200 and response.json()["total_count"] is None:
			# No duplicates found
			return True
		else:
			# Found duplicates
			print ("OK\t- Kit already present in KITIntel\t\t- sha256: {}\t- kit.kitname: {}".format(str(zipsha256), str(os.path.basename(target_zip[:-4]))))
			return False
	except Exception as e:
		# Error
		print ("ERROR\t- Failed duplicate checking POST request")
		if debug:
			print (e)
			traceback.print_exc()
		# If search fails upload the kit anyway
		return True

def submitPost(zipfile, debug):
	# KIT API environment variable
	try:
		if os.environ['KITAPI'] is not None:
			Env_KIT_APIKey = os.environ['KITAPI']
		else:
			Env_KIT_APIKey = session['apikey']
	except Exception as e:
		# Error
		print ("ERROR\t- KITAPI key error - Ensure an API key has been added to the environment variables")
		exit()

	cert_val = session.get('cert_val')
	certs = os.environ.get('KITINTEL_CERT_VALIDATION') or (cert_val.lower() == 'true') if cert_val else True

	file_size = os.stat(zipfile).st_size

	headers = {'x-api-key': Env_KIT_APIKey, 'Content-Type': 'application/json'}
	data = {
		"file_name": os.path.basename(zipfile)
	}

	res = requests.post(URL_Endpoint + "/submit", headers=headers, data=json.dumps(data), verify=certs)
	if debug:
		print (res.json())
	if res.status_code == 200:
		presigned_headers = {'Content-Type': 'application/binary'}
		presigned_url = res.json()['upload_url']
		with open(zipfile, 'rb') as f:
			try:
				with tqdm(total=file_size, unit="B", unit_scale=True, unit_divisor=1024) as t:
					wrapped_file = CallbackIOWrapper(t.update, f, "read")
					upload = requests.put(
						presigned_url, headers=presigned_headers, data=wrapped_file, verify=certs)
					if upload.status_code == 200:
						return True
					if upload.status_code != 200:
						print("ERROR\t- Upload Failed at state 1")
						if debug:
							print (upload.status_code)
							print (upload.text)
			except Exception as e:
				print("ERROR\t- Upload Failed at state 2")
				if debug:
					print(e)
					traceback.print_exc()
	return False


def submit(ziplocation, recursive, debug):
	# KIT API environment variable
	try:
		if os.environ['KITAPI'] is not None:
			Env_KIT_APIKey = os.environ['KITAPI']
		else:
			Env_KIT_APIKey = session['apikey']
	except Exception as e:
		# Error
		print ("ERROR\t- KITAPI key error - Ensure an API key has been added to the environment variables")
		exit()

	cert_val = session.get('cert_val')
	certs = os.environ.get('KITINTEL_CERT_VALIDATION') or (cert_val.lower() == 'true') if cert_val else True

	if debug:
		print ("-------------------------------------------------------------------------------------")
	try:
		#Allow for multiple kit uploads
		for target_zip in ziplocation:
			if debug:
				print ("Running: {}".format(target_zip))
			# Check if current item is a directory
			if os.path.isdir(target_zip):
				ziplocation = []
				# If recursive value is set
				if recursive:
					# Create a list of all files in all directories which end in .zip
					ziplocation = glob.glob(target_zip + '/**/*.zip', recursive=True)
				else:
					# Create a list of all files in current directory which end in .zip
					ziplocation = glob.glob(target_zip + '/*.zip', recursive=False)
				if debug:
					print (ziplocation)
				submit(ziplocation, False, debug)
			else:
				if debug:
					print ("File Entered")
				# Item is not a dir so can be processed as a file
				with open(target_zip, 'rb') as f:
					# Generate SHA256 for file
					h  = hashlib.sha256()
					b  = bytearray(128*1024)
					mv = memoryview(b)
					# Initialize variable
					# This is a 0 byte file hash - Sha256 fails with a 0 byte file.
					zipsha256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
					for n in iter(lambda : f.readinto(mv), 0):
						h.update(mv[:n])
						zipsha256 = h.hexdigest()
					# Check to ensure hash has generated
					if len(zipsha256) < 64:
						# Error
						print("ERROR\t- Unable to generate hash\t\t\t- kit.kitname: {}".format(str(os.path.basename(target_zip))))
						traceback.print_exc()
					else:
						try:
							while True:
								if debug:
									print ("Validation Check - start")
								upload = validateZip(target_zip, zipsha256, debug)
								if debug:
									print ("Validation Check - end")
								if not upload:
									if debug:
										print ("File is not a valid zip - no upload required")
									break
								if debug:
									print ("Duplicate Check - start")
								upload = duplicateChecker(target_zip, zipsha256, debug)
								if debug:
									print ("Duplicate Check - end")
								if not upload:
									if debug:
										print ("File is Duplicate - no upload required")
									break
								# if not duplicate:
								if debug:
									print("New kit - starting upload {} to S3...".format(str(os.path.basename(target_zip))))
								counter = 0
								while True:
									if debug:
										print ("Submission start")
									success = submitPost(target_zip, debug)
									if debug:
										print ("Submission end")
									if success:
										print ("SUCCESS\t- File submitted\t\t\t\t- sha256: {}\t- kit.kitname: {}".format(str(zipsha256), str(os.path.basename(target_zip[:-4]))))
										break
									if counter > 10:
										print("ERROR\t- Attempted upload 10 times and failed\t\t- kit.kitname: {}".format(str(os.path.basename(target_zip[:-4]))))
										break
									counter = counter + 1
						except Exception as e:
							if debug:
								print (e)
								traceback.print_exc()
	except OSError as e:
		# Handle if a directory is inputted
		if e.errno == 21:
			pass
	except Exception as e:
		# Error
		print ("ERROR\t- Error in kit submission")
		if debug:
			traceback.print_exc()
			print (e)
