from flask import Flask, render_template, Blueprint, flash, request, current_app
from APIWrapper.wrapper import validateZip, duplicateChecker, submitPost
import os
from random import randrange
import requests
import json
import hashlib
import traceback
import re
import subprocess

submit_BP = Blueprint('submit_BP', __name__)

def submitFile(filesList=None):
	print (filesList)
	final_file_dict = []
	try:
		if filesList:
			for file in filesList:
				print (file)
				fileDict = {}
				print (fileDict)
				try:
					save_file_dir = './kits/'
					# print (save_file_dir + file, os.path.join(current_app.root_path, 'static/temp_kitstore/', file))
					os.replace(save_file_dir + file, os.path.join(current_app.root_path, 'static/temp_kitstore/', file))
					fileDict["key"] = randrange(99999999999999999999999999999999)
					fileDict["filename"] = file
					fileDict["upload"] = 'Maybe'
					fileDict["status"] = "Processing..."
				except Exception as e:
					print (e)
					fileDict["key"] = randrange(99999999999999999999999999999999)
					fileDict["filename"] = file.filename
					fileDict["upload"] = 'False'
					fileDict["status"] = "Error - Unknown Error #42"
				final_file_dict.append(fileDict)
		else:
			filesList = []
			for file in request.files.getlist("file"):
				fileDict = {}
				try:
					file.save(os.path.join(current_app.root_path, 'static/temp_kitstore/', file.filename))
					fileDict["key"] = randrange(99999999999999999999999999999999)
					fileDict["filename"] = file.filename
					fileDict["upload"] = 'Maybe'
					fileDict["status"] = "Processing..."
				except Exception as e:
					if len(file.filename) < 1:
						print (e)
						fileDict["key"] = randrange(99999999999999999999999999999999)
						fileDict["filename"] = 'Null'
						fileDict["upload"] = 'False'
						fileDict["status"] = "Error - No file selected"
					else:
						print (e)
						fileDict["key"] = randrange(99999999999999999999999999999999)
						fileDict["filename"] = file.filename
						fileDict["upload"] = 'False'
						fileDict["status"] = "Error - Unknown Error #42"
				final_file_dict.append(fileDict)
	except Exception as e:
		print (e)
		# flash('Error - Unknown Error #43', 'danger')
	print ("Line 62 submit routes.py")
	print (final_file_dict)
	try:
		for file in final_file_dict:
			print ("Line 73 - file: " + str(file))
			if file["upload"] == True:
				pass
			else:
				target_zip = os.path.join(current_app.root_path, 'static/temp_kitstore/', file['filename'])
				# print ("HERE#1")
				# Item is not a dir so can be processed as a file
				with open(target_zip, 'rb') as f:
					# Generate SHA256 for file
					h  = hashlib.sha256()
					b  = bytearray(128*1024)
					mv = memoryview(b)
					# Initialize variable
					# This is a 0 byte file hash - Sha256 fails with a 0 byte file.
					zipsha256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
					for n in iter(lambda : f.readinto(mv), 0):
						h.update(mv[:n])
						zipsha256 = h.hexdigest()
					# Check to ensure hash has generated
					# print (zipsha256)
					if len(zipsha256) < 64:
						# Error
						print("ERROR\t- Unable to generate hash\t\t\t- kit.kitname: {}".format(str(os.path.basename(target_zip))))
						file["upload"] = 'False'
						file["status"] = "Error - Unable to generate hash"
						traceback.print_exc()
					else:
						try:
							while True:
								# print ("Validation Check - start")
								upload = validateZip(target_zip, zipsha256, True)
								# print ("Validation Check - end")
								if not upload:
									print ("File is not a valid zip - no upload required")
									file["upload"] = 'False'
									file["status"] = "Error - File is not a valid zip"
									break
								# print ("Duplicate Check - start")
								upload = duplicateChecker(target_zip, zipsha256, True)
								# print ("Duplicate Check - end")
								if not upload:
									print ("File is Duplicate - no upload required")
									file["upload"] = 'True'
									file["status"] = "Duplicate kit - Already present in KITIntel"
									file["key"] = str(zipsha256)
									break
								# if not duplicate:
								print("New kit - starting upload {} to S3...".format(str(os.path.basename(target_zip))))
								counter = 0
								while True:
									# print ("Submission start")
									success = submitPost(target_zip, True)
									# print ("Submission end")
									if success:
										print ("SUCCESS\t- File submitted\t\t\t\t- sha256: {}\t- kit.kitname: {}".format(str(zipsha256), str(os.path.basename(target_zip[:-4]))))
										file["upload"] = 'True'
										file["status"] = "Kit Processed"
										break
									if counter > 10:
										print("ERROR\t- Attempted upload 10 times and failed\t\t- kit.kitname: {}".format(str(os.path.basename(target_zip[:-4]))))
										file["upload"] = 'False'
										file["status"] = "Error - Attempted upload 10 times and failed"
										break
									counter = counter + 1
						except Exception as e:
							print (e)
							traceback.print_exc()
		return final_file_dict

	except Exception as e:
		return final_file_dict
		# print ("Line 137")
		# print (e)
		# flash('Unknown Error', 'danger')



@submit_BP.route("/submit", methods=['GET', 'POST'])
def submitRoute():
	if request.method == 'GET':
		return render_template('submit.html', title='Submit | KITIntel')
	elif request.method == 'POST':
		# Lands here for a URL upload
		try:
			body = request.form['text']
			body = body.splitlines()
			urls = []
			filesList = []
			for item in body:
				try:
					hit = re.search('(https?:\\/\\/)?[\\w-]+\\.[a-z]{2,7}\\S+', item)
					hit = hit.group()
					if hit:
						if len(hit) > 3:
							if hit.startswith("http"):
								urls.append(hit)
							else:
								urls.append("http://" + str(hit))
				except Exception as e:
					print (e)
					flash('Error - Please try again - {}'.format(item), 'danger')
					# return render_template('submit.html', title='Submit | KITIntel')

			if len(urls) == 0:
				flash('No URLs found - Please try again', 'danger')
				# return render_template('submit.html', title='Submit | KITIntel')
			else:
				processedFilesList = []
				for item in urls:
					string = "echo '" + str(item) + "' | ./kitwebsite/static/kitphishr -d -c 200"
					# print (string)
					result2 = subprocess.getoutput(string)
					# print (result2)
					if len(result2) > 2:
						if "\n" in result2:
							urlsItems = result2.split('\n')
						else:
							urlsItems = []
							urlsItems.append(result2)
						for url in urlsItems:
							save_filename = url.replace('//', '_')
							save_filename = save_filename.replace('/', '_')
							save_filename = save_filename.replace(':', '')
							filesList.append(save_filename)
					else:
						pass
				if len(filesList) > 0: 
					print ("Fileslist - " + str(filesList))
					output = submitFile(filesList)
					print (output)
					processedFilesList = output
				else:
					pass
				return render_template('processing.html', title='Submit | KITIntel', filesList=processedFilesList)

		# Lands here for a file upload
		except KeyError:
			print ("submit routes.py - Line 200")
			filesList = submitFile()
		return render_template('processing.html', title='Submit | KITIntel', filesList=filesList)


@submit_BP.route("/processing", methods=['GET'])
def processing(filesList):
	# print (filesList)
	return render_template('submit.html', title='Submit | KITIntel')
