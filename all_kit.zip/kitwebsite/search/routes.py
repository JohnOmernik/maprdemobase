from flask import render_template, Blueprint, request, flash, redirect, url_for
from APIWrapper.wrapper import search, content
from kitwebsite.search.app import parseSearchResponse
from kitwebsite.main.app import format_file_size
from datetime import date
import json
import urllib.parse


search_BP = Blueprint('search_BP', __name__)


@search_BP.route("/search", methods=['GET'])
def searchRoute():
	response = search('filename:*', numberInput=50)
	try:
		# json_object = json.loads(response['content'])
		searchTerm = 'filename:*'

		headings = ("Date", "Kit Name", "Fullfilename", "Sha256", "Size")
		data = parseSearchResponse(response['content'])
		for item in data:
			old_size = item['file_size']
			new_size = format_file_size(old_size)
			item['file_size'] = new_size

		return render_template('search.html', title='Search | KITIntel', searchTerm=searchTerm, headings=headings, data=data, searchdata=response['data'])
	except ValueError as e:
		flash(response, 'danger')
		response = (search('filename:*',numberInput=50))
	

@search_BP.route("/submit_search", methods=['POST'])
def search_submit():
	uniqueValue = None
	try:
		uniqueValue = request.form.get('uniqueKitsSelect')
	except Exception as e:
		pass

	resultsCount = request.form.get('resultsCount')
	
	searchGTEDate = request.form['searchGTEDate']
	searchLTEDate = request.form['searchLTEDate']

	searchTermRaw = request.form['searchBar']
	searchTerm = urllib.parse.quote(searchTermRaw.encode('utf8'), safe='')

	return redirect(url_for('search_BP.searchTermFunc', searchparam=searchTerm, uv=uniqueValue, count=resultsCount, searchGTEDate=searchGTEDate, searchLTEDate=searchLTEDate))


@search_BP.route("/search/<searchparam>", methods=['GET'])
def searchTermFunc(searchparam):
	uniqueValue = None
	searchLTEDate = None
	searchGTEDate = None
	if 'uv' in request.args:
		uniqueValue = request.args['uv']
	
	if 'count' in request.args:
		resultsCount = request.args['count']
	else:
		resultsCount = 50
	
	if 'searchLTEDate' in request.args:
		searchLTEDate = request.args['searchLTEDate']
	else:
		searchLTEDate = date.today()

	if 'searchGTEDate' in request.args:
		searchGTEDate = request.args['searchGTEDate']
	else:
		dt = date.today()
		dt = dt.replace(year=dt.year-5)
		searchGTEDate = dt

	parsedSearchParam = urllib.parse.unquote(searchparam)

	# print ('parsedSearchParam#1: {}'.format(parsedSearchParam))
	# print ('numberInput#1: {}'.format(resultsCount))
	# print ('dateLTEInput#1: {}'.format(searchLTEDate))
	# print ('dateGTEInput#1: {}'.format(searchGTEDate))
	# print ('uniqueInput#1: {}'.format(uniqueValue))
	response = search(parsedSearchParam, filterInput='datetime, kit.kitname, fullfilename, file.sha256, file.size, kit.UUID, file.UUID', numberInput=resultsCount, dateLTEInput=searchLTEDate, dateGTEInput=searchGTEDate, uniqueInput=uniqueValue)
	# print ('response#1: {}'.format(response))
	try:
		headings = ("Date", "Kit Name", "Fullfilename", "Sha256", "Size")
		data = parseSearchResponse(response['content'])

		for item in data:
			old_size = item['file_size']
			new_size = format_file_size(old_size)
			item['file_size'] = new_size

		# print ('Data#1: {}'.format(data))
		# print ("Count: {}".format(resultsCount))
		# print ("searchGTEDate: {}".format(searchGTEDate))
		# print ("searchLTEDate: {}".format(searchLTEDate))
		return render_template('search.html', title='Search | KITIntel', searchTerm=parsedSearchParam, headings=headings, data=data, count=resultsCount, uv=uniqueValue, dateLTEInput=searchLTEDate, dateGTEInput=searchGTEDate, searchdata=response['data'])
	except Exception as e:
		print (e)
		flash(response, 'danger')
		return redirect(url_for('search_BP.searchRoute'))
	



