import json

def parseSearchResponse(res):
	# print(response)
	if type(res) != dict:
		res = json.loads(res)
	# print(response)
	# res = json.dumps(res)
	# print(res[:10])
	# print(type(res))
	data = []

	# print (type(res))

	for i in range(len(res['results'])):
		final = {}

		try:
			final['datetime'] = res['results'][i]['datetime']
		except Exception as e:
			pass
		try:
			final['kit_UUID'] = res['results'][i]['kit']['UUID']
		except Exception as e:
			pass
		try:
			final['kit_md5'] = res['results'][i]['kit']['md5']
		except Exception as e:
			pass
		try:
			final['kit_size'] = res['results'][i]['kit']['size']
		except Exception as e:
			pass
		try:
			final['kit_ssdeep'] = res['results'][i]['kit']['ssdeep']
		except Exception as e:
			pass
		try:
			final['kit_filetype'] = res['results'][i]['kit']['filetype']
		except Exception as e:
			pass
		try:
			final['kit_sha256'] = res['results'][i]['kit']['sha256']
		except Exception as e:
			pass
		try:
			final['kit_kitname'] = res['results'][i]['kit']['kitname']
		except Exception as e:
			pass

		try:
			final['file_count'] = res['total_count']
		except Exception as e:
			pass
		try:
			final['file_filetype'] = res['results'][i]['file']['filetype']
		except Exception as e:
			pass
		try:
			final['file_sha256'] = res['results'][i]['file']['sha256']
		except Exception as e:
			pass
		try:
			final['file_fullfilename'] = res['results'][i]['file']['fullfilename']
		except Exception as e:
			pass
		try:
			final['file_ssdeep'] = res['results'][i]['file']['ssdeep']
		except Exception as e:
			pass
		try:
			final['file_filename'] = res['results'][i]['file']['filename']
		except Exception as e:
			pass
		try:
			final['file_size'] = res['results'][i]['file']['size']
		except Exception as e:
			pass
		try:
			final['file_UUID'] = res['results'][i]['file']['UUID']
		except Exception as e:
			pass
		try:
			final['file_md5'] = res['results'][i]['file']['md5']
		except Exception as e:
			pass

		data.append(final)
	return data

