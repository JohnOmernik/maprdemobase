from APIWrapper.wrapper import search
import json



def countFileTypes(res, fileDictCount):
	# print (res)
	# print (len(res['results']))
	for i in range(len(res['results'])):
		# print (res)
		filetype = res['results'][i]['file']['filetype']
		# print (filetype)
		try:
			if len(filetype) < 1:
				filetype = '_blank_'
			if filetype not in fileDictCount:
				fileDictCount[filetype] = 1
			else:
				fileDictCount[filetype] += 1

		except Exception as e:
			pass

	return fileDictCount

def fileCountfunc(response, searchparam):
	if type(response) != dict:
		response = json.loads(response)
	# print (response[:30])
	# scrollID = int(response['scroll_id'])
	# print ("Inital scroll_id: {}".format(scrollID))
	fileDictCount = {}
	fileDictCount = countFileTypes(response, fileDictCount)
	# while scrollID != 0:
	# 	# print (type(scrollID))
	# 	try:
	# 		searchTerm = "scroll_id:{} IN {}".format(scrollID, searchparam)
	# 		output = search(searchTerm, numberInput=2000)
	# 		res = json.loads(output['content'])
	# 		fileDictCount = countFileTypes(res, fileDictCount)
	# 		scrollID = int(res['scroll_id'])
	# 		# print ("New scroll_id: {}".format(scrollID))
	# 	except Exception as e:
	# 		if scrollID == 0:
	# 			break
	# 		print (e)
	# 		print ("ERROR #489 - Start")
	# 		print (res)
	# 		print (scrollID)
	# 		print (type(scrollID))
	# 		print (e)
	# 		print ("ERROR #489 - End")
	# 		return fileDictCount
	return fileDictCount

def datapull(data, searchparam):
	finalJSON = {}
	resultsVar = []
	
	response = json.loads(data)

	resultsVar = resultsVar + response['results']

	scrollID = int(response['scroll_id'])
	while scrollID != 0:
		searchTerm = "scroll_id:{} IN {}".format(scrollID, searchparam)
		output = search(searchTerm, numberInput=1000)
		res = json.loads(output['content'])
		scrollID = int(res['scroll_id'])
		resultsVar = resultsVar + res['results']

	# print (response)

	finalJSON['results'] = resultsVar
	finalJSON['total_count'] = response['total_count']
	# print (json.dumps(results)[:30])
	# print ("type(results): {}".format(type(results)))
	return finalJSON
