from flask import render_template, Blueprint, flash, redirect, url_for
from APIWrapper.wrapper import search, content
from kitwebsite.search.app import parseSearchResponse
from kitwebsite.kit.app import fileCountfunc, datapull
from kitwebsite.main.app import format_file_size
import operator
from datetime import datetime
from urllib.parse import quote


kit_BP = Blueprint('kit_BP', __name__)


@kit_BP.route("/kit/<kitUUID>", methods=['GET'], defaults={'fileUUID' : 'None'})
@kit_BP.route("/kit/<kitUUID>/<fileUUID>", methods=['GET'])
def kit(kitUUID, fileUUID):
	# print ("kit.UUID:" + kitUUID)
	searchparam = "kit.UUID:" + str(kitUUID)
	response = search(searchparam, numberInput=1000)
	response = datapull(response['content'], searchparam)
	try:
		data = parseSearchResponse(response)

		item = data[0]
		old_size = item['kit_size']
		new_size = format_file_size(old_size)
		item['kit_size'] = new_size

		if fileUUID == 'None':
			fileCount = fileCountfunc(response, searchparam)
			sortedFileCount = dict( sorted(fileCount.items(), key=operator.itemgetter(1),reverse=True))
			# print ("data: {}".format(data))
			# print ("data_length: {}".format(len(data)))
			return render_template('kit.html', title=kitUUID + ' | KITIntel', data=data, fileCount=sortedFileCount, kitUUIDparam=kitUUID)
		else:
			try:
				contentResponse = content([fileUUID], False, False)
				for item in data:
					if item['file_UUID'] == fileUUID:
						filepath = quote(item['file_fullfilename'], safe="")

						old_size = item['file_size']
						new_size = format_file_size(old_size)
						item['file_size'] = new_size

			except Exception as e:
				print (e)
				# print (response)
				flash(contentResponse, 'danger')
				kit(kitUUID, fileUUID)
				# Need to get this to return to previous kit.UUID page
				# return redirect(url_for('kit_BP.searchRoute'))
			# print ("data: {}".format(response))
			# print ("data_length: {}".format(len(data)))
			return render_template('kit.html', title=kitUUID + ' | KITIntel', data=data, kitUUIDparam=kitUUID, fileUUID=fileUUID, content=contentResponse, filepath=filepath)
	except ValueError as e:
		print (e)
		print (response)
		flash(response, 'danger')
		kit(kitUUID, fileUUID)
		# return redirect(url_for('kit_BP.searchRoute'))


@kit_BP.route("/kit/<kitUUID>/<fileUUID>/DOM", methods=['GET'])
def previewContent(kitUUID, fileUUID):
	contentResponse = content([fileUUID], False, False)
	return render_template('preview.html', content=contentResponse)

