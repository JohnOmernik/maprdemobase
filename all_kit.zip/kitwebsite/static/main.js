// // Theme Switcher
// const toggleSwitch = document.querySelector('.theme-switch input[type="checkbox"]');
// const currentTheme = localStorage.getItem('theme');

// // Set the default theme to dark if there is no stored theme
// const defaultTheme = currentTheme || 'dark';
// document.documentElement.setAttribute('data-theme', defaultTheme);

// if (defaultTheme === 'dark') {
//     toggleSwitch.checked = true;
// }

// function switchTheme(e) {
//     if (e.target.checked) {
//         document.documentElement.setAttribute('data-theme', 'light');
//         localStorage.setItem('theme', 'light');
//     } else {
//         document.documentElement.setAttribute('data-theme', 'dark');
//         localStorage.setItem('theme', 'dark');
//     }
// }

// toggleSwitch.addEventListener('change', switchTheme, false);

// $(document).ready(function() {
//     // Check for click events on the navbar burger icon
//     $(".navbar-burger").click(function() {
//         // Toggle the "is-active" class on both the "navbar-burger" and the "navbar-menu"
//         $(".navbar-burger").toggleClass("is-active");
//         $(".navbar-menu").toggleClass("is-active");
//     });
// });


function debugInputFunction() {
	var element = document.getElementById('debugInput'),
  	style = window.getComputedStyle(element),
    display = style.getPropertyValue('display');
	console.log(display);
	if (display === 'none') {
	  document.getElementById("debugInput").style.display = "";
	}
	else {
	  document.getElementById("debugInput").style.display = "none";	
	}
}
