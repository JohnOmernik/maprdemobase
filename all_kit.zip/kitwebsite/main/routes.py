from APIWrapper.wrapper import search
from flask import render_template, Blueprint, current_app, request, flash, session
from kitwebsite.search.app import parseSearchResponse
from kitwebsite.submit.routes import submitFile
import json
import os
import re
import requests
import subprocess



main_BP = Blueprint('main_BP', __name__)

@main_BP.route("/", methods=['GET', 'POST'])
@main_BP.route("/home", methods=['GET', 'POST'])
def home():

	try:
		certs = os.environ['KITINTEL_CERT_VALIDATION']
	except KeyError:
		certs = True
	except Exception as e:
		print (f"Error: {e}")

	if request.method == "POST":
		body = request.form['text']

		urls = []
		filesList = []

		try:
			hit = re.search('(https?:\\/\\/)?[\\w-]+\\.[a-z]{2,7}\\S+', body)
			hit = hit.group()
			if hit:
				if len(hit) > 3:
					if hit.startswith("http"):
						urls.append(hit)
					else:
						urls.append("http://" + str(hit))
		except Exception as e:
			print (e)
			flash('Unrecognized URL - Please try again', 'danger')
			response = search('filename:*', None, 1, '5y', None, None, None, None)
			data = parseSearchResponse(response['content'])
			for item in data:
				fileCount = item['file_count']
				fileCount = "{:,}".format(fileCount)
			r = requests.get('https://raw.githubusercontent.com/JCyberSec/count/main/count.txt', verify=certs)
			kitCount = r.text.strip()
			kitCount = "{:,}".format(int(kitCount))
			return render_template('index.html', title='Home | KITIntel', fileCount=fileCount, kitCount=kitCount)


		if len(urls) == 0:
			flash('No URLs found - Please try again', 'danger')
			response = search('filename:*', None, 1, '5y', None, None, None, None)
			data = parseSearchResponse(response['content'])
			for item in data:
				fileCount = item['file_count']
				fileCount = "{:,}".format(fileCount)
			r = requests.get('https://raw.githubusercontent.com/JCyberSec/count/main/count.txt', verify=certs)
			kitCount = r.text.strip()
			kitCount = "{:,}".format(int(kitCount))
			return render_template('index.html', title='Home | KITIntel', fileCount=fileCount, kitCount=kitCount)

		else:
			url = ['echo', urls[0]]

			result1 = subprocess.getoutput('pwd')
			string = "echo '" + str(urls[0]) + "' | ./kitwebsite/static/kitphishr -d"
			result2 = subprocess.getoutput(string)
			if len(result2) > 3:
				if "\n" in result2:
					urlsItems = result2.split('\n')
				else:
					urlsItems = []
					urlsItems.append(result2)
				for url in urlsItems:
					save_filename = url.replace('/', '_')
					save_filename = save_filename.replace(':', '')

					save_filename = save_filename.replace('__', '_', 1)

					filesList.append(save_filename)
				

				processedFilesList = submitFile(filesList)


				print ("returing")
				return render_template('processing.html', title='Submit | KITIntel', filesList=processedFilesList)

			else:
				flash('No kit found on the domain', 'info')
				response = search('filename:*', numberInput=1)
				data = parseSearchResponse(response['content'])
				for item in data:
					fileCount = item['file_count']
					fileCount = "{:,}".format(fileCount)
				r = requests.get('https://raw.githubusercontent.com/JCyberSec/count/main/count.txt', verify=certs)
				kitCount = r.text.strip()
				kitCount = "{:,}".format(int(kitCount))
				return render_template('index.html', title='Home | KITIntel', fileCount=fileCount, kitCount=kitCount)
				

	if request.method == "GET":
		response = search('filename:*', numberInput=1)
		data = parseSearchResponse(response['content'])
		for item in data:
			fileCount = item['file_count']
			fileCount = "{:,}".format(fileCount)
		r = requests.get('https://raw.githubusercontent.com/JCyberSec/count/main/count.txt', verify=certs)
		kitCount = r.text.strip()
		kitCount = "{:,}".format(int(kitCount))
		return render_template('index.html', title='Home | KITIntel', fileCount=fileCount, kitCount=kitCount)

@main_BP.route("/configure", methods=['GET', 'POST'])
def config():
	if request.method == 'GET':
		if 'apikey' in session:
			key =  '----------------------' + str(session['apikey'])[-5:]
			return render_template('configure.html', key=key)
		else:
			key = 'Add API key here'
			return render_template('configure.html', key=key)
	elif request.method == 'POST':
		if 'cert_val' in request.form:
			cert = request.form['cert_val']
			session['cert_val'] = cert
			session.modified = True
			flash("Updated Certificate validation", 'success')
			return render_template('configure.html')
		elif 'apikey' in request.form:
			session['apikey'] = request.form['apikey']
			key =  '----------------------' + str(session['apikey'])[-5:]
			flash("Updated KITIntel API key", 'success')
			return render_template('configure.html', key=key)
		else:
			flash("Incorrect POST requirements", 'warning')
			return render_template('configure.html')


@main_BP.route("/api")
def api():
	return render_template('api.html', title='API | KITIntel')

@main_BP.route("/hunting")
def hunting():
	return render_template('hunting.html', title='Hunting | KITIntel')

@main_BP.route("/premium")
def premium():
	return render_template('premium.html', title='Premium | KITIntel')

@main_BP.route("/about")
def about():
	return render_template('about.html', title='About | KITIntel')

@main_BP.route("/changelog")
def changelog():
	return render_template('changelog.html', title='Changelog | KITIntel')
