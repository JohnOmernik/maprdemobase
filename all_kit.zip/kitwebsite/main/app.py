def format_file_size(size_in_bytes):
    # Define the units and their corresponding size in bytes
    units = ["B", "KB", "MB", "GB", "TB"]
    # Calculate the appropriate unit to use based on the size in bytes
    unit_index = 0
    while size_in_bytes >= 1024 and unit_index < len(units) - 1:
        size_in_bytes /= 1024
        unit_index += 1
    # Format the size as a string with two decimal places, or as an integer if less than 1 KB
    if size_in_bytes < 1 and unit_index == 0:
        return f"{size_in_bytes:.0f} {units[unit_index]}"
    else:
        return f"{size_in_bytes:.2f} {units[unit_index]}"