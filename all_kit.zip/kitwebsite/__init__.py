from flask import Flask

def create_app():
	app = Flask(__name__)

	from kitwebsite.kit.routes import kit_BP
	from kitwebsite.main.routes import main_BP
	from kitwebsite.search.routes import search_BP
	from kitwebsite.submit.routes import submit_BP
	from kitwebsite.errors.handlers import errors
	app.register_blueprint(errors)
	app.register_blueprint(kit_BP)
	app.register_blueprint(main_BP)
	app.register_blueprint(search_BP)
	app.register_blueprint(submit_BP)

	return app